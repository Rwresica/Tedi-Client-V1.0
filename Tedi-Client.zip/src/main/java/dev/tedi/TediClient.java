package dev.tedi;

import com.mojang.blaze3d.platform.InputConstants;
import dev.tedi.gui.ClickGui;
import dev.tedi.module.*;
import dev.tedi.util.Proj;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.DeltaTracker;
import org.lwjgl.glfw.GLFW;

public class TediClient implements ClientModInitializer {
    private boolean rshiftWasDown;

    @Override
    public void onInitializeClient() {
        Modules.init();
        ClientTickEvents.START_CLIENT_TICK.register(mc -> Hud.I.captureTarget(mc));
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudRenderCallback.EVENT.register(this::hud);
    }

    private void tick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;

        boolean down = InputConstants.isKeyDown(mc.getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT);
        if (down && !rshiftWasDown && mc.screen == null) mc.setScreen(new ClickGui());
        rshiftWasDown = down;

        for (Module m : Modules.all) {
            if (m.key > 0) {
                boolean k = InputConstants.isKeyDown(mc.getWindow(), m.key);
                if (k && !m.wasKeyDown && mc.screen == null) m.toggle();
                m.wasKeyDown = k;
            }
        }

        for (Module m : Modules.all) if (m.enabled) m.onTick(mc);

        if (StorageEsp.I.enabled || (Hud.I.enabled && Hud.I.blocks.value)) StorageEsp.scan(mc);
    }

    private void hud(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.options.hideGui) return;
        float pt = dt.getGameTimeDeltaPartialTick(true);
        Proj.begin(mc, g, pt);
        for (Module m : Modules.all) if (m.enabled) m.onRender(g, mc, pt);
    }
}
