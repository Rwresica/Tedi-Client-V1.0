package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class Hud extends Module {
    public static Hud I;
    private record Broken(BlockPos pos, String name, long time) {}

    public final Setting.Bool list = add(new Setting.Bool("Module List", true));
    public final Setting.Hue color = add(new Setting.Hue("List Color", 195));
    public final Setting.Bool players = add(new Setting.Bool("Player Nametags", true));
    public final Setting.Bool showHealth = add(new Setting.Bool("Show Health", true));
    public final Setting.Bool showDist = add(new Setting.Bool("Show Distance", true));
    public final Setting.Num playerRange = add(new Setting.Num("Player Range", 128, 16, 256, 8));
    public final Setting.Bool blocks = add(new Setting.Bool("Block Nametags", true));
    public final Setting.Num blockRange = add(new Setting.Num("Block Range", 24, 4, 64, 2));
    public final Setting.Num brokenTime = add(new Setting.Num("Broken Block Secs", 4, 1, 15, 1));

    private final List<Broken> broken = new ArrayList<>();
    private BlockPos mining;
    private String miningName = "";

    public Hud() {
        super("HUD", "Module list, player and block nametags.", "HUD", true);
        I = this;
    }

    /** Runs before vanilla handles the mouse so instant-breaks are still captured. */
    public void captureTarget(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        HitResult hr = mc.hitResult;
        if (mc.options.keyAttack.isDown() && hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.level.getBlockState(bhr.getBlockPos());
            if (!st.isAir()) {
                mining = bhr.getBlockPos().immutable();
                miningName = st.getBlock().getName().getString();
            }
        }
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null) return;
        if (mining != null) {
            if (mc.level.getBlockState(mining).isAir()) {
                broken.add(new Broken(mining, miningName, System.currentTimeMillis()));
                mining = null;
            } else if (!mc.options.keyAttack.isDown()) {
                mining = null;
            }
        }
        long life = (long) (brokenTime.value * 1000);
        long now = System.currentTimeMillis();
        broken.removeIf(b -> now - b.time() > life);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        Font f = mc.font;

        if (players.value) {
            for (AbstractClientPlayer p : mc.level.players()) {
                if (p == mc.player && !Freecam.active()) continue;
                Vec3 pos = p.getPosition(pt);
                double d = Math.sqrt(pos.distanceToSqr(Proj.cx, Proj.cy, Proj.cz));
                if (d > playerRange.value) continue;
                if (!Proj.project(pos.x, pos.y + p.getBbHeight() + 0.9, pos.z)) continue;
                StringBuilder sb = new StringBuilder(p.getName().getString());
                int col = Colors.ACCENT;
                if (showHealth.value) {
                    float hp = p.getHealth();
                    sb.append(" ").append(String.format(Locale.ROOT, "%.1f", hp));
                    col = hp > 14 ? 0xFF7CFF8A : hp > 7 ? 0xFFFFE066 : 0xFFFF6B6B;
                }
                if (showDist.value) sb.append(" [").append((int) d).append("m]");
                Proj.label(g, sb.toString(), Proj.px, Proj.py, col);
            }
        }

        if (blocks.value) {
            double r2 = blockRange.value * blockRange.value;
            for (StorageEsp.Hit h : StorageEsp.hits) {
                Vec3 c = h.pos().getCenter();
                if (c.distanceToSqr(Proj.cx, Proj.cy, Proj.cz) > r2) continue;
                if (Proj.project(c.x, c.y + 0.8, c.z)) Proj.label(g, h.name(), Proj.px, Proj.py, Colors.TEXT);
            }
            long now = System.currentTimeMillis();
            long life = (long) (brokenTime.value * 1000);
            for (Broken b : broken) {
                Vec3 c = b.pos().getCenter();
                float fade = 1f - (float) (now - b.time()) / (float) life;
                int a = Math.max(5, (int) (255 * Math.min(1f, fade * 2f)));
                if (Proj.project(c.x, c.y + 0.9, c.z)) Proj.label(g, b.name(), Proj.px, Proj.py, (a << 24) | 0xFFD27F);
            }
        }

        if (list.value) {
            List<Module> on = new ArrayList<>();
            for (Module m : Modules.all) if (m.enabled) on.add(m);
            on.sort(Comparator.comparingInt((Module m) -> -f.width(m.name)));
            int W = g.guiWidth(), y = 3, col = color.argb();
            for (Module m : on) {
                int w = f.width(m.name);
                g.fill(W - w - 9, y - 1, W, y + 10, 0x90000000);
                g.fill(W - 2, y - 1, W, y + 10, col);
                g.drawString(f, m.name, W - w - 6, y + 1, col, false);
                y += 11;
            }
        }
    }
}
