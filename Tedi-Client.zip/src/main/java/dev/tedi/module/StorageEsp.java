package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

public class StorageEsp extends Module {
    public static StorageEsp I;
    public record Hit(BlockPos pos, int type, String name) {}
    public static final List<Hit> hits = new ArrayList<>();
    private static int timer;

    public final Setting.Bool chests = add(new Setting.Bool("Chests", true));
    public final Setting.Bool trapped = add(new Setting.Bool("Trapped Chests", true));
    public final Setting.Bool ender = add(new Setting.Bool("Ender Chests", true));
    public final Setting.Bool barrels = add(new Setting.Bool("Barrels", true));
    public final Setting.Bool shulkers = add(new Setting.Bool("Shulkers", true));
    public final Setting.Bool others = add(new Setting.Bool("Hoppers/Furnaces/etc", false));
    public final Setting.Hue cChest = add(new Setting.Hue("Chest Color", 35));
    public final Setting.Hue cTrapped = add(new Setting.Hue("Trapped Color", 0));
    public final Setting.Hue cEnder = add(new Setting.Hue("Ender Color", 280));
    public final Setting.Hue cBarrel = add(new Setting.Hue("Barrel Color", 100));
    public final Setting.Hue cShulker = add(new Setting.Hue("Shulker Color", 320));
    public final Setting.Hue cOther = add(new Setting.Hue("Other Color", 195));
    public final Setting.Bool boxes = add(new Setting.Bool("Boxes", true));
    public final Setting.Bool tracers = add(new Setting.Bool("Tracers", true));
    public final Setting.Num tracerWidth = add(new Setting.Num("Tracer Width", 1.0, 0.5, 4.0, 0.5));
    public final Setting.Num boxWidth = add(new Setting.Num("Box Width", 1.0, 0.5, 4.0, 0.5));
    public final Setting.Num range = add(new Setting.Num("Range", 128, 16, 256, 8));

    public StorageEsp() {
        super("StorageESP", "Highlights storage blocks through walls.", "General", false);
        I = this;
    }

    public static int classify(BlockEntity be) {
        if (be instanceof TrappedChestBlockEntity) return 1;
        if (be instanceof ChestBlockEntity) return 0;
        if (be instanceof EnderChestBlockEntity) return 2;
        if (be instanceof BarrelBlockEntity) return 3;
        if (be instanceof ShulkerBoxBlockEntity) return 4;
        if (be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity
                || be instanceof AbstractFurnaceBlockEntity || be instanceof BrewingStandBlockEntity) return 5;
        return -1;
    }

    /** Called every tick when StorageESP or HUD block nametags need data. */
    public static void scan(Minecraft mc) {
        if (mc.level == null || mc.player == null) { hits.clear(); return; }
        if (++timer % 10 != 0) return;
        hits.clear();
        int r = Math.min(mc.options.getEffectiveRenderDistance(), 16);
        int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
        for (int x = pcx - r; x <= pcx + r; x++) {
            for (int z = pcz - r; z <= pcz + r; z++) {
                LevelChunk ch = mc.level.getChunkSource().getChunkNow(x, z);
                if (ch == null) continue;
                for (BlockEntity be : ch.getBlockEntities().values()) {
                    int t = classify(be);
                    if (t < 0) continue;
                    hits.add(new Hit(be.getBlockPos(), t, be.getBlockState().getBlock().getName().getString()));
                }
            }
        }
    }

    public boolean typeEnabled(int t) {
        return switch (t) {
            case 0 -> chests.value; case 1 -> trapped.value; case 2 -> ender.value;
            case 3 -> barrels.value; case 4 -> shulkers.value; default -> others.value;
        };
    }

    public int colorFor(int t) {
        return switch (t) {
            case 0 -> cChest.argb(); case 1 -> cTrapped.argb(); case 2 -> cEnder.argb();
            case 3 -> cBarrel.argb(); case 4 -> cShulker.argb(); default -> cOther.argb();
        };
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        int sx = g.guiWidth() / 2, sy = g.guiHeight() / 2; // crosshair
        double r2 = range.value * range.value;
        for (Hit h : hits) {
            if (!typeEnabled(h.type())) continue;
            Vec3 c = h.pos().getCenter();
            if (c.distanceToSqr(Proj.cx, Proj.cy, Proj.cz) > r2) continue;
            int col = colorFor(h.type());
            if (boxes.value) Proj.box(g, new AABB(h.pos()), boxWidth.f(), col);
            if (tracers.value && Proj.project(c.x, c.y, c.z)) {
                Proj.line(g, sx, sy, Proj.px, Proj.py, tracerWidth.f(), col);
            }
        }
    }
}
