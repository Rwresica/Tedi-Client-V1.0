package dev.tedi.module;

import dev.tedi.setting.Setting;
import dev.tedi.util.Proj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;

/** Flags loaded chunks that show signs of player activity. */
public class SusChunk extends Module {
    public static SusChunk I;
    private record Info(int cx, int cz, int amethyst, int storage, int minY, int maxY) {}

    public final Setting.Bool amethyst = add(new Setting.Bool("Grown Amethyst", true));
    public final Setting.Num minAmethyst = add(new Setting.Num("Min Amethyst", 1, 1, 20, 1));
    public final Setting.Bool storage = add(new Setting.Bool("Storage Density", true));
    public final Setting.Num minStorage = add(new Setting.Num("Min Storage", 6, 2, 50, 1));
    public final Setting.Bool boxes = add(new Setting.Bool("Boxes", true));
    public final Setting.Bool tracers = add(new Setting.Bool("Tracers", false));
    public final Setting.Hue color = add(new Setting.Hue("Color", 285));
    public final Setting.Num scanSpeed = add(new Setting.Num("Chunks Per Tick", 4, 1, 16, 1));

    private final Map<Long, Info> flagged = new HashMap<>();
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();

    public SusChunk() {
        super("SusChunk", "Flags chunks with grown amethyst or dense storage (player activity).", "General", true);
        I = this;
    }

    @Override public void onDisable() { flagged.clear(); queue.clear(); }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        if (queue.isEmpty()) {
            int r = Math.min(mc.options.getEffectiveRenderDistance(), 32);
            int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
            for (int x = pcx - r; x <= pcx + r; x++)
                for (int z = pcz - r; z <= pcz + r; z++) queue.add(new int[]{x, z});
        }
        for (int n = 0; n < scanSpeed.i() && !queue.isEmpty(); n++) {
            int[] c = queue.poll();
            long key = (((long) c[0]) << 32) ^ (c[1] & 0xFFFFFFFFL);
            LevelChunk ch = mc.level.getChunkSource().getChunkNow(c[0], c[1]);
            if (ch == null) { flagged.remove(key); continue; }
            Info info = analyze(ch, c[0], c[1]);
            if (info == null) flagged.remove(key); else flagged.put(key, info);
        }
    }

    private Info analyze(LevelChunk ch, int cx, int cz) {
        int am = 0, st = 0, minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        if (amethyst.value) {
            LevelChunkSection[] secs = ch.getSections();
            for (int i = 0; i < secs.length; i++) {
                LevelChunkSection sec = secs[i];
                if (sec.hasOnlyAir()) continue;
                if (!sec.maybeHas(s -> s.is(Blocks.AMETHYST_CLUSTER))) continue;
                int baseY = ch.getMinY() + i * 16;
                for (int x = 0; x < 16; x++)
                    for (int y = 0; y < 16; y++)
                        for (int z = 0; z < 16; z++)
                            if (sec.getBlockState(x, y, z).is(Blocks.AMETHYST_CLUSTER)) {
                                am++;
                                minY = Math.min(minY, baseY + y);
                                maxY = Math.max(maxY, baseY + y);
                            }
            }
        }
        if (storage.value) {
            for (BlockEntity be : ch.getBlockEntities().values()) {
                int t = StorageEsp.classify(be);
                if (t >= 0 && t <= 4) {
                    st++;
                    int y = be.getBlockPos().getY();
                    minY = Math.min(minY, y);
                    maxY = Math.max(maxY, y);
                }
            }
        }
        boolean hitA = amethyst.value && am >= minAmethyst.i();
        boolean hitS = storage.value && st >= minStorage.i();
        if (!hitA && !hitS) return null;
        return new Info(cx, cz, am, st, minY, maxY);
    }

    @Override
    public void onRender(GuiGraphics g, Minecraft mc, float pt) {
        int sx = g.guiWidth() / 2, sy = g.guiHeight() / 2;
        int col = color.argb();
        for (Info i : flagged.values()) {
            double top = Math.max(i.maxY() + 1, i.minY() + 3);
            AABB b = new AABB(i.cx() * 16, i.minY(), i.cz() * 16, i.cx() * 16 + 16, top, i.cz() * 16 + 16);
            if (boxes.value) Proj.box(g, b, 1f, col);
            Vec3 c = b.getCenter();
            if (tracers.value && Proj.project(c.x, c.y, c.z)) Proj.line(g, sx, sy, Proj.px, Proj.py, 1f, col);
            if (Proj.project(c.x, top + 1, c.z)) {
                String t = "Sus Chunk";
                if (i.amethyst() > 0) t += "  A:" + i.amethyst();
                if (i.storage() > 0) t += "  S:" + i.storage();
                Proj.label(g, t, Proj.px, Proj.py, col);
            }
        }
    }
}
