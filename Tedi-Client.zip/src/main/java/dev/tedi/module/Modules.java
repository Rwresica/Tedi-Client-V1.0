package dev.tedi.module;

import java.util.ArrayList;
import java.util.List;

public final class Modules {
    public static final List<Module> all = new ArrayList<>();
    private Modules() {}

    public static void init() {
        all.add(new StorageEsp());
        all.add(new Freecam());
        all.add(new SusChunk());
        all.add(new AutoTotem());
        all.add(new NameProtect());
        Hud hud = new Hud();
        all.add(hud);
        hud.setEnabled(true);
    }
}
