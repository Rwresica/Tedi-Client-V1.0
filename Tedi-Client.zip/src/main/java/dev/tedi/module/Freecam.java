package dev.tedi.module;

import dev.tedi.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public class Freecam extends Module {
    public static Freecam I;
    public final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 0.1, 10.0, 0.1));
    public final Setting.Num smoothness = add(new Setting.Num("Smoothness", 0.7, 0.0, 0.95, 0.05));

    private Vec3 pos = Vec3.ZERO, prev = Vec3.ZERO, vel = Vec3.ZERO;
    public float yaw, pitch;

    public Freecam() {
        super("Freecam", "Fly the camera through blocks.", "General", true);
        I = this;
    }

    public static boolean active() { return I != null && I.enabled; }

    @Override
    public void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) { enabled = false; return; }
        pos = prev = mc.player.getEyePosition();
        vel = Vec3.ZERO;
        yaw = mc.player.getYRot();
        pitch = mc.player.getXRot();
    }

    public Vec3 renderPos(float pt) { return prev.lerp(pos, pt); }

    /** Called from the mouse-look mixin with the raw mouse deltas. */
    public void look(double dYaw, double dPitch) {
        yaw += (float) (dYaw * 0.15);
        pitch = Mth.clamp(pitch + (float) (dPitch * 0.15), -90f, 90f);
    }

    @Override
    public void onTick(Minecraft mc) {
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        Vec3 f = new Vec3(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
        Vec3 l = new Vec3(Math.cos(yr), 0, Math.sin(yr));
        boolean free = mc.screen == null;
        double fw = free ? ((mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0)) : 0;
        double st = free ? ((mc.options.keyLeft.isDown() ? 1 : 0) - (mc.options.keyRight.isDown() ? 1 : 0)) : 0;
        double vt = free ? ((mc.options.keyJump.isDown() ? 1 : 0) - (mc.options.keyShift.isDown() ? 1 : 0)) : 0;
        Vec3 dir = f.scale(fw).add(l.scale(st)).add(0, vt, 0);
        Vec3 target = dir.lengthSqr() > 1.0E-6 ? dir.normalize().scale(speed.value * 0.5) : Vec3.ZERO;
        double a = 1.0 - smoothness.value;
        vel = vel.add(target.subtract(vel).scale(a));
        prev = pos;
        pos = pos.add(vel);
    }
}
