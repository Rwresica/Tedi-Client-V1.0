package dev.tedi.gui;

import dev.tedi.module.Module;
import dev.tedi.module.Modules;
import dev.tedi.setting.Setting;
import dev.tedi.util.Colors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

public class ClickGui extends Screen {
    private static final int ACCENT = Colors.ACCENT, TEXT = Colors.TEXT;
    private static final int PANEL = 0xE00E1116, ROW = 0xD0161A21, ROW_HOVER = 0xD01F2630, TRACK = 0xFF2A323C;
    private static final int PW = 150, X0 = 30, Y0 = 36, GAP = 12, HEAD = 16, ROWH = 16;

    private record Region(int x, int y, int w, int h, IntConsumer click, DoubleConsumer drag) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private final List<Region> regions = new ArrayList<>();
    private Region dragging;
    private Module bindTarget, hoverMod;
    private Setting.Str editing;

    public ClickGui() { super(Component.literal("Tedi Client")); }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float dt) {}

    @Override
    public void render(GuiGraphics g, int mx, int my, float dt) {
        Font f = Minecraft.getInstance().font;
        regions.clear();
        hoverMod = null;
        g.fill(0, 0, this.width, this.height, 0x66000000);

        String[] cats = {"General", "HUD"};
        for (int pi = 0; pi < cats.length; pi++) {
            int x = X0 + pi * (PW + GAP), y = Y0;
            g.fill(x, y, x + PW, y + HEAD, PANEL);
            String title = cats[pi].toUpperCase();
            g.drawString(f, title, x + (PW - f.width(title)) / 2, y + 4, ACCENT, false);
            y += HEAD;
            for (Module m : Modules.all) {
                if (!m.category.equals(cats[pi])) continue;
                boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROWH;
                g.fill(x, y, x + PW, y + ROWH, hov ? ROW_HOVER : ROW);
                if (m.enabled) g.fill(x, y, x + 2, y + ROWH, ACCENT);
                g.drawString(f, m.name.toUpperCase(), x + 7, y + 4, m.enabled ? ACCENT : TEXT, false);
                int px = x + PW - 22, py = y + 4;
                g.fill(px, py, px + 16, py + 8, m.enabled ? 0xFF2C6E85 : 0xFF3A424C);
                int kx = m.enabled ? px + 9 : px + 1;
                g.fill(kx, py + 1, kx + 6, py + 7, m.enabled ? ACCENT : 0xFFB8C4CF);
                final Module fm = m;
                regions.add(new Region(x, y, PW, ROWH, b -> {
                    if (b == 0) fm.toggle(); else if (b == 1) fm.expanded = !fm.expanded;
                }, null));
                if (hov) hoverMod = m;
                y += ROWH;
                if (m.expanded) y = drawSettings(g, f, m, x, y);
            }
            g.fill(x, y, x + PW, y + 2, PANEL);
        }

        if (dragging != null && dragging.drag() != null) dragging.drag().accept(mx);

        if (hoverMod != null) {
            int tw = f.width(hoverMod.description);
            g.fill(mx + 8, my + 6, mx + 16 + tw, my + 19, 0xE00E1116);
            g.drawString(f, hoverMod.description, mx + 12, my + 9, ACCENT, false);
        }
    }

    private int drawSettings(GuiGraphics g, Font f, Module m, int x, int y) {
        for (Setting s : m.settings) {
            if (s instanceof Setting.Bool b) {
                g.fill(x, y, x + PW, y + 14, ROW);
                int bx = x + 8, by = y + 3;
                g.fill(bx, by, bx + 8, by + 8, 0xFF3A424C);
                if (b.value) g.fill(bx + 1, by + 1, bx + 7, by + 7, ACCENT);
                g.drawString(f, b.name.toUpperCase(), bx + 13, y + 3, TEXT, false);
                regions.add(new Region(x, y, PW, 14, bt -> { if (bt == 0) b.value = !b.value; }, null));
                y += 14;
            } else if (s instanceof Setting.Num n) {
                g.fill(x, y, x + PW, y + 22, ROW);
                g.drawString(f, n.name.toUpperCase(), x + 8, y + 3, TEXT, false);
                String v = n.text();
                g.drawString(f, v, x + PW - 8 - f.width(v), y + 3, ACCENT, false);
                int tx = x + 8, tw = PW - 16, ty = y + 16;
                int fw = (int) (tw * n.ratio());
                g.fill(tx, ty, tx + tw, ty + 2, TRACK);
                g.fill(tx, ty, tx + fw, ty + 2, ACCENT);
                g.fill(tx + fw - 1, ty - 2, tx + fw + 2, ty + 4, 0xFFFFFFFF);
                regions.add(new Region(x, y + 10, PW, 12, null, mxx -> n.setFromRatio((mxx - tx) / (double) tw)));
                y += 22;
            } else if (s instanceof Setting.Hue h) {
                g.fill(x, y, x + PW, y + 22, ROW);
                g.drawString(f, h.name.toUpperCase(), x + 8, y + 3, TEXT, false);
                g.fill(x + PW - 20, y + 2, x + PW - 8, y + 10, h.argb());
                int tx = x + 8, tw = PW - 16, ty = y + 15;
                for (int i = 0; i < tw; i += 2)
                    g.fill(tx + i, ty, tx + Math.min(i + 2, tw), ty + 3, 0xFF000000 | dev.tedi.util.Colors.hsv(i / (double) tw * 360.0));
                int kx = tx + (int) (tw * h.hue / 360.0);
                g.fill(kx - 1, ty - 2, kx + 2, ty + 5, 0xFFFFFFFF);
                regions.add(new Region(x, y + 10, PW, 12, null, mxx -> h.hue = Math.max(0, Math.min(360, (mxx - tx) / (double) tw * 360.0))));
                y += 22;
            } else if (s instanceof Setting.Str st) {
                g.fill(x, y, x + PW, y + 26, ROW);
                g.drawString(f, st.name.toUpperCase(), x + 8, y + 3, TEXT, false);
                g.fill(x + 8, y + 13, x + PW - 8, y + 23, 0xFF0A0C10);
                String shown = st.value + (editing == st && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
                g.drawString(f, shown, x + 11, y + 14, editing == st ? ACCENT : TEXT, false);
                regions.add(new Region(x, y, PW, 26, bt -> { if (bt == 0) { editing = st; bindTarget = null; } }, null));
                y += 26;
            }
        }
        if (m.bindable) {
            g.fill(x, y, x + PW, y + 14, ROW);
            String t = "BIND: " + (bindTarget == m ? "PRESS A KEY..." : keyName(m.key));
            g.drawString(f, t, x + 8, y + 3, bindTarget == m ? ACCENT : TEXT, false);
            regions.add(new Region(x, y, PW, 14, bt -> { if (bt == 0) { bindTarget = m; editing = null; } }, null));
            y += 14;
        }
        return y;
    }

    private static String keyName(int k) {
        if (k <= 0) return "NONE";
        if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F12) return "F" + (k - GLFW.GLFW_KEY_F1 + 1);
        String n = null;
        try { n = GLFW.glfwGetKeyName(k, 0); } catch (Throwable ignored) {}
        return n != null ? n.toUpperCase() : "KEY " + k;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        int b = e.button();
        editing = null;
        if (bindTarget != null) bindTarget = null;
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (!r.in(mx, my)) continue;
            if (r.drag() != null && b == 0) { dragging = r; r.drag().accept(mx); }
            if (r.click() != null) r.click().accept(b);
            return true;
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        return super.mouseReleased(e);
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (bindTarget != null) {
            if (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) bindTarget.key = -1;
            else if (k != GLFW.GLFW_KEY_ESCAPE) bindTarget.key = k;
            bindTarget = null;
            return true;
        }
        if (editing != null) {
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_ESCAPE) editing = null;
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !editing.value.isEmpty())
                editing.value = editing.value.substring(0, editing.value.length() - 1);
            return true;
        }
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT || k == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (editing != null && editing.value.length() < 16) {
            editing.value += Character.toString(e.codepoint());
            return true;
        }
        return super.charTyped(e);
    }
}
