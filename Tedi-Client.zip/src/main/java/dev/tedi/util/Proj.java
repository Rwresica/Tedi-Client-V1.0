package dev.tedi.util;

import dev.tedi.module.Freecam;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** World -> GUI-screen projection so ESP / tracers / nametags can be drawn in 2D. */
public final class Proj {
    public static double cx, cy, cz, px, py;
    private static double fx, fy, fz, rx, rz, ux, uy, uz, tanHalf, aspect;
    private static int w, h;

    private Proj() {}

    public static void begin(Minecraft mc, GuiGraphics g, float pt) {
        double yaw, pitch;
        if (Freecam.active()) {
            Vec3 p = Freecam.I.renderPos(pt);
            cx = p.x; cy = p.y; cz = p.z;
            yaw = Freecam.I.yaw; pitch = Freecam.I.pitch;
        } else {
            Vec3 p = mc.player.getEyePosition(pt);
            cx = p.x; cy = p.y; cz = p.z;
            yaw = mc.player.getViewYRot(pt); pitch = mc.player.getViewXRot(pt);
        }
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        fx = -Math.sin(yr) * Math.cos(pr);
        fy = -Math.sin(pr);
        fz = Math.cos(yr) * Math.cos(pr);
        rx = -Math.cos(yr);
        rz = -Math.sin(yr);
        ux = -rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy;
        double fov = mc.options.fov().get();
        tanHalf = Math.tan(Math.toRadians(fov) / 2.0);
        w = g.guiWidth(); h = g.guiHeight();
        aspect = (double) w / (double) h;
    }

    /** Result goes to px/py. Returns false if the point is behind the camera. */
    public static boolean project(double x, double y, double z) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        double zz = dx * fx + dy * fy + dz * fz;
        if (zz < 0.05) return false;
        double xx = dx * rx + dz * rz;
        double yy = dx * ux + dy * uy + dz * uz;
        px = w / 2.0 + (xx / zz) / (tanHalf * aspect) * (w / 2.0);
        py = h / 2.0 - (yy / zz) / tanHalf * (h / 2.0);
        return true;
    }

    public static void line(GuiGraphics g, double x1, double y1, double x2, double y2, float width, int argb) {
        double dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.5f || len > 6000f) return;
        var p = g.pose();
        p.pushMatrix();
        p.translate((float) x1, (float) y1);
        p.rotate((float) Math.atan2(dy, dx));
        p.translate(0f, -width / 2f);
        p.scale(1f, width);
        g.fill(0, 0, (int) Math.ceil(len), 1, argb);
        p.popMatrix();
    }

    public static void box(GuiGraphics g, AABB b, float width, int argb) {
        double[] sx = new double[8], sy = new double[8];
        boolean[] ok = new boolean[8];
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? b.minX : b.maxX;
            double y = (i & 2) == 0 ? b.minY : b.maxY;
            double z = (i & 4) == 0 ? b.minZ : b.maxZ;
            ok[i] = project(x, y, z);
            sx[i] = px; sy[i] = py;
        }
        for (int i = 0; i < 8; i++) {
            for (int bit = 1; bit <= 4; bit <<= 1) {
                if ((i & bit) == 0) {
                    int j = i | bit;
                    if (ok[i] && ok[j]) line(g, sx[i], sy[i], sx[j], sy[j], width, argb);
                }
            }
        }
    }

    public static void label(GuiGraphics g, String text, double x, double y, int argb) {
        Font f = Minecraft.getInstance().font;
        int tw = f.width(text);
        int ix = (int) x - tw / 2, iy = (int) y - 4;
        g.fill(ix - 2, iy - 2, ix + tw + 2, iy + 10, 0x90000000);
        g.drawString(f, text, ix, iy, argb, false);
    }
}
